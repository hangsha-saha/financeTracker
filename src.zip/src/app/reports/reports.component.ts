import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';

import {
  ApexAxisChartSeries, ApexChart, ApexXAxis, ApexYAxis,
  ApexDataLabels, ApexTooltip, ApexPlotOptions, ApexFill,
  ApexLegend, ApexStroke, ApexMarkers, ApexGrid,
  ApexNonAxisChartSeries, ApexResponsive,
  ChartComponent
} from 'ng-apexcharts';

import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

// ── Types ──────────────────────────────────────────────────────────
export interface MonthData {
  date: string;
  month: string;
  income: number;
  expense: number;
  breakdown: { [key: string]: number };
}

export type BarChartOptions = {
  series:      ApexAxisChartSeries;
  chart:       ApexChart;
  colors:      string[];
  xaxis:       ApexXAxis;
  yaxis:       ApexYAxis;
  tooltip:     ApexTooltip;
  plotOptions: ApexPlotOptions;
  dataLabels:  ApexDataLabels;
  legend:      ApexLegend;
  grid:        ApexGrid;
};

export type AreaChartOptions = {
  series:     ApexAxisChartSeries;
  chart:      ApexChart;
  colors:     string[];
  fill:       ApexFill;
  xaxis:      ApexXAxis;
  yaxis:      ApexYAxis;
  tooltip:    ApexTooltip;
  dataLabels: ApexDataLabels;
  stroke:     ApexStroke;
  grid:       ApexGrid;
  markers:    ApexMarkers;
};

export type DonutChartOptions = {
  series:     ApexNonAxisChartSeries;
  chart:      ApexChart;
  labels:     string[];
  colors:     string[];
  tooltip:    ApexTooltip;
  legend:     ApexLegend;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  responsive: ApexResponsive[];
};

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit, OnDestroy {

  @ViewChild('barChartRef')   barChartRef!:   ChartComponent;
  @ViewChild('donutChartRef') donutChartRef!: ChartComponent;
  @ViewChild('areaChartRef')  areaChartRef!:  ChartComponent;

  // ── Date filters ──
  startDate: string = '2026-02-01';
  endDate:   string = '2026-02-28';

  // ── Summary values ──
  totalIncome:  number = 0;
  totalExpense: number = 0;
  netProfit:    number = 0;

  // ── Toast ──
  toastMsg:     string  = '';
  toastType:    string  = '';
  toastVisible: boolean = false;
  private toastTimer: any;

  // ════════════════════════════════════════
  // DUMMY DATA  (replace with API call)
  // ════════════════════════════════════════
  readonly ALL_MONTHS: MonthData[] = [
    { date:'2025-09-01', month:'Sep 2025', income:180000, expense:110000,
      breakdown:{ Salaries:38000,'Raw Materials':28000,Rent:25000,Utilities:7000,Marketing:7000,Supplies:5000 } },
    { date:'2025-10-01', month:'Oct 2025', income:195000, expense:125000,
      breakdown:{ Salaries:40000,'Raw Materials':33000,Rent:25000,Utilities:8000,Marketing:12000,Supplies:7000 } },
    { date:'2025-11-01', month:'Nov 2025', income:210000, expense:118000,
      breakdown:{ Salaries:42000,'Raw Materials':29000,Rent:25000,Utilities:7500,Marketing:9000,Supplies:5500 } },
    { date:'2025-12-01', month:'Dec 2025', income:230000, expense:140000,
      breakdown:{ Salaries:45000,'Raw Materials':38000,Rent:25000,Utilities:9000,Marketing:14000,Supplies:9000 } },
    { date:'2026-01-01', month:'Jan 2026', income:215000, expense:128000,
      breakdown:{ Salaries:44000,'Raw Materials':32000,Rent:25000,Utilities:8200,Marketing:11000,Supplies:7800 } },
    { date:'2026-02-01', month:'Feb 2026', income:224650, expense:132200,
      breakdown:{ Salaries:45000,'Raw Materials':30000,Rent:35000,Utilities:8500,Marketing:8200,Supplies:5500 } },
  ];

  // ── Chart options ──
  barChartOptions!:   Partial<BarChartOptions>;
  areaChartOptions!:  Partial<AreaChartOptions>;
  donutChartOptions!: Partial<DonutChartOptions>;

  ngOnInit(): void {
    this.initCharts();
    this.applyFilter();
  }

  ngOnDestroy(): void {
    clearTimeout(this.toastTimer);
  }

  // ════════════════════════════════════════
  // HELPERS
  // ════════════════════════════════════════

  getFilteredMonths(): MonthData[] {
    if (!this.startDate || !this.endDate) return this.ALL_MONTHS;
    return this.ALL_MONTHS.filter(m => m.date >= this.startDate && m.date <= this.endDate);
  }

  aggregateBreakdown(months: MonthData[]): { labels: string[]; values: number[] } {
    const totals: { [key: string]: number } = {};
    months.forEach(m => {
      Object.entries(m.breakdown).forEach(([cat, val]) => {
        totals[cat] = (totals[cat] || 0) + val;
      });
    });
    return { labels: Object.keys(totals), values: Object.values(totals) };
  }

  fmtINR(val: number): string {
    return '₹' + Math.abs(val).toLocaleString('en-IN');
  }

  fmtPDF(val: number, negative: boolean = false): string {
    return (negative ? '-Rs. ' : 'Rs. ') + Math.abs(val).toLocaleString('en-IN');
  }

  get profitClass(): string {
    return this.netProfit >= 0 ? 'profit-pos' : 'profit-neg';
  }

  get netProfitDisplay(): string {
    return (this.netProfit < 0 ? '-' : '') + this.fmtINR(this.netProfit);
  }

  // ════════════════════════════════════════
  // FILTER — called on date change
  // ════════════════════════════════════════

  applyFilter(): void {
    const filtered = this.getFilteredMonths();

    if (filtered.length === 0) {
      this.totalIncome  = 0;
      this.totalExpense = 0;
      this.netProfit    = 0;
      this.updateCharts([], [], [], [], [], []);
      return;
    }

    this.totalIncome  = filtered.reduce((s, m) => s + m.income,  0);
    this.totalExpense = filtered.reduce((s, m) => s + m.expense, 0);
    this.netProfit    = this.totalIncome - this.totalExpense;

    const months   = filtered.map(m => m.month);
    const incomes  = filtered.map(m => m.income);
    const expenses = filtered.map(m => m.expense);
    const profits  = filtered.map(m => m.income - m.expense);
    const bd       = this.aggregateBreakdown(filtered);

    this.updateCharts(months, incomes, expenses, profits, bd.labels, bd.values);
  }

  // ════════════════════════════════════════
  // CHARTS — init with default data
  // ════════════════════════════════════════

  private initCharts(): void {
    const initial = this.getFilteredMonths();
    const bd      = this.aggregateBreakdown(initial);
    const months  = initial.map(m => m.month);

    // ── Bar chart ──
    this.barChartOptions = {
      chart: { type: 'bar', height: 320, toolbar: { show: false }, fontFamily: 'inherit', animations: { enabled: true } },
      series: [
        { name: 'Income',  data: initial.map(m => m.income)  },
        { name: 'Expense', data: initial.map(m => m.expense) },
      ],
      colors: ['#4CAF50', '#EF5350'],
      xaxis: { categories: months },
      yaxis: { labels: { formatter: (v: number) => '₹' + (v / 1000).toFixed(0) + 'k' } },
      tooltip: { y: { formatter: (v: number) => '₹' + v.toLocaleString('en-IN') } },
      plotOptions: { bar: { columnWidth: '55%', borderRadius: 4 } },
      dataLabels: { enabled: false },
      legend: { position: 'top' },
      grid: { borderColor: '#f0f0f0' },
    };

    // ── Donut chart ──
    this.donutChartOptions = {
      chart: { type: 'donut', height: 320, fontFamily: 'inherit' },
      series: bd.values,
      labels: bd.labels,
      colors: ['#4CAF50', '#FF9800', '#9C27B0', '#0288D1', '#FF8C00', '#E91E63'],
      tooltip: { y: { formatter: (v: number) => '₹' + v.toLocaleString('en-IN') } },
      legend: { position: 'bottom' },
      dataLabels: { formatter: (val: number) => val.toFixed(1) + '%' },
      plotOptions: { pie: { donut: { size: '60%' } } },
      responsive: [{ breakpoint: 600, options: { chart: { height: 260 }, legend: { position: 'bottom' } } }],
    };

    // ── Area chart ──
    this.areaChartOptions = {
      chart: { type: 'area', height: 320, toolbar: { show: false }, fontFamily: 'inherit', animations: { enabled: true } },
      series: [{ name: 'Net Profit', data: initial.map(m => m.income - m.expense) }],
      colors: ['#FF8C00'],
      fill: { type: 'gradient', gradient: { shadeIntensity: 1, opacityFrom: 0.4, opacityTo: 0.05 } },
      xaxis: { categories: months },
      yaxis: { labels: { formatter: (v: number) => '₹' + (v / 1000).toFixed(0) + 'k' } },
      tooltip: { y: { formatter: (v: number) => '₹' + v.toLocaleString('en-IN') } },
      dataLabels: { enabled: false },
      stroke: { curve: 'smooth', width: 2 },
      grid: { borderColor: '#f0f0f0' },
      markers: { size: 4, colors: ['#FF8C00'], strokeColors: '#fff', strokeWidth: 2 },
    };
  }

  private updateCharts(
    months: string[], incomes: number[], expenses: number[],
    profits: number[], bdLabels: string[], bdValues: number[]
  ): void {
    if (this.barChartRef) {
      this.barChartRef.updateOptions({
        xaxis: { categories: months },
        series: [
          { name: 'Income',  data: incomes  },
          { name: 'Expense', data: expenses },
        ]
      });
    }
    if (this.areaChartRef) {
      this.areaChartRef.updateOptions({
        xaxis: { categories: months },
        series: [{ name: 'Net Profit', data: profits }]
      });
    }
    if (this.donutChartRef) {
      this.donutChartRef.updateOptions({ labels: bdLabels });
      this.donutChartRef.updateSeries(bdValues);
    }
  }

  // ════════════════════════════════════════
  // PDF EXPORT
  // ════════════════════════════════════════

  exportPdf(): void {
    const doc      = new jsPDF();
    const filtered = this.getFilteredMonths();
    const bd       = this.aggregateBreakdown(filtered);

    // Header band
    doc.setFillColor(255, 140, 0);
    doc.rect(0, 0, 220, 28, 'F');
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.text('FinanceTracker - Financial Report', 14, 12);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Period: ${this.startDate}  to  ${this.endDate}`, 14, 22);

    // Generated date
    doc.setTextColor(100, 100, 100);
    doc.setFontSize(10);
    doc.text(`Generated: ${new Date().toLocaleDateString('en-IN')}`, 150, 35);

    // Summary table
    doc.setTextColor(30, 30, 30);
    doc.setFontSize(13);
    doc.setFont('helvetica', 'bold');
    doc.text('Summary', 14, 44);

    autoTable(doc, {
      startY: 48,
      head: [['Metric', 'Amount']],
      body: [
        ['Total Income',  this.fmtPDF(this.totalIncome)],
        ['Total Expense', this.fmtPDF(this.totalExpense)],
        ['Net Profit',    this.fmtPDF(this.netProfit, this.netProfit < 0)],
      ],
      headStyles: { fillColor: [255, 140, 0], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [255, 250, 240] },
      styles: { fontSize: 11 },
    });

    // Monthly breakdown table
    const y1 = (doc as any).lastAutoTable.finalY + 10;
    doc.setFontSize(13); doc.setFont('helvetica', 'bold'); doc.setTextColor(30, 30, 30);
    doc.text('Monthly Breakdown', 14, y1);

    autoTable(doc, {
      startY: y1 + 4,
      head: [['Month', 'Income', 'Expense', 'Profit']],
      body: filtered.map(m => {
        const p = m.income - m.expense;
        return [m.month, this.fmtPDF(m.income), this.fmtPDF(m.expense), this.fmtPDF(p, p < 0)];
      }),
      headStyles: { fillColor: [255, 140, 0], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [255, 250, 240] },
      styles: { fontSize: 10 },
    });

    // Expense breakdown table
    const y2 = (doc as any).lastAutoTable.finalY + 10;
    doc.setFontSize(13); doc.setFont('helvetica', 'bold'); doc.setTextColor(30, 30, 30);
    doc.text('Expense Breakdown', 14, y2);

    autoTable(doc, {
      startY: y2 + 4,
      head: [['Category', 'Amount', '% of Total']],
      body: bd.labels.map((label, i) => [
        label,
        this.fmtPDF(bd.values[i]),
        ((bd.values[i] / this.totalExpense) * 100).toFixed(1) + '%'
      ]),
      headStyles: { fillColor: [255, 140, 0], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [255, 250, 240] },
      styles: { fontSize: 10 },
    });

    doc.save(`FinanceReport_${this.startDate}_to_${this.endDate}.pdf`);
    this.showToast('PDF exported successfully!', 'success');
  }

  // ════════════════════════════════════════
  // EXCEL EXPORT
  // ════════════════════════════════════════

  exportExcel(): void {
    const filtered = this.getFilteredMonths();
    const bd       = this.aggregateBreakdown(filtered);
    const wb       = XLSX.utils.book_new();

    // Sheet 1 — Summary
    const ws1 = XLSX.utils.aoa_to_sheet([
      ['FinanceTracker - Financial Report'],
      [`Period: ${this.startDate} to ${this.endDate}`],
      [`Generated: ${new Date().toLocaleDateString('en-IN')}`],
      [],
      ['SUMMARY'],
      ['Metric', 'Amount (Rs.)'],
      ['Total Income',  this.totalIncome],
      ['Total Expense', this.totalExpense],
      ['Net Profit',    this.netProfit],
    ]);
    ws1['!cols'] = [{ wch: 22 }, { wch: 18 }];
    XLSX.utils.book_append_sheet(wb, ws1, 'Summary');

    // Sheet 2 — Monthly Breakdown
    const ws2 = XLSX.utils.aoa_to_sheet([
      ['Month', 'Income (Rs.)', 'Expense (Rs.)', 'Profit (Rs.)'],
      ...filtered.map(m => [m.month, m.income, m.expense, m.income - m.expense])
    ]);
    ws2['!cols'] = [{ wch: 12 }, { wch: 16 }, { wch: 16 }, { wch: 16 }];
    XLSX.utils.book_append_sheet(wb, ws2, 'Monthly Breakdown');

    // Sheet 3 — Expense Breakdown
    const ws3 = XLSX.utils.aoa_to_sheet([
      ['Category', 'Amount (Rs.)', '% of Total'],
      ...bd.labels.map((label, i) => [
        label,
        bd.values[i],
        +((bd.values[i] / this.totalExpense) * 100).toFixed(1)
      ])
    ]);
    ws3['!cols'] = [{ wch: 20 }, { wch: 16 }, { wch: 14 }];
    XLSX.utils.book_append_sheet(wb, ws3, 'Expense Breakdown');

    const buf  = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([buf], { type: 'application/octet-stream' });
    saveAs(blob, `FinanceReport_${this.startDate}_to_${this.endDate}.xlsx`);
    this.showToast('Excel exported successfully!', 'success');
  }

  // ════════════════════════════════════════
  // TOAST
  // ════════════════════════════════════════

  showToast(msg: string, type: string = 'info'): void {
    this.toastMsg     = msg;
    this.toastType    = type;
    this.toastVisible = true;
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => this.toastVisible = false, 3000);
  }
}