import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  // Form fields
  username: string = '';
  password: string = '';
  rememberMe: boolean = false;

  // UI state
  passwordVisible: boolean = false;
  isLoading: boolean = false;
  showSuccess: boolean = false;

  // Error messages
  usernameError: string = '';
  passwordError: string = '';
  loginError: string = '';

  // Valid credentials (hardcoded for demo)
  private readonly VALID_USERNAME = 'admin';
  private readonly VALID_PASSWORD = 'admin';

  constructor(private router: Router) {}

  ngOnInit(): void {
    const remembered = localStorage.getItem('rememberedUsername');
    if (remembered) {
      this.username = remembered;
      this.rememberMe = true;
    }
  }

  togglePasswordVisibility(): void {
    this.passwordVisible = !this.passwordVisible;
  }

  clearFieldError(field: 'username' | 'password'): void {
    if (field === 'username') this.usernameError = '';
    if (field === 'password') this.passwordError = '';
    this.loginError = '';
  }

  handleLogin(): void {
    // Reset errors
    this.usernameError = '';
    this.passwordError = '';
    this.loginError = '';

    // Validate
    let valid = true;

    if (!this.username.trim()) {
      this.usernameError = 'Please enter your username.';
      valid = false;
    }

    if (!this.password) {
      this.passwordError = 'Please enter your password.';
      valid = false;
    }

    if (!valid) return;

    // Show loading
    this.isLoading = true;

    setTimeout(() => {
      if (this.username === this.VALID_USERNAME && this.password === this.VALID_PASSWORD) {

        if (this.rememberMe) {
          localStorage.setItem('rememberedUsername', this.username);
        } else {
          localStorage.removeItem('rememberedUsername');
        }

        this.isLoading = false;
        this.showSuccess = true;

        setTimeout(() => {
          this.router.navigate(['/dashboard']);
        }, 1500);

      } else {
        this.isLoading = false;
        this.loginError = 'Invalid username or password. Please try again.';
        this.usernameError = ' ';
        this.passwordError = ' ';
      }
    }, 1200);
  }

  onRegisterClick(event: Event): void {
    event.preventDefault();
    this.router.navigate(['/register']);
  }

}