import { Component, OnInit } from '@angular/core';

export interface Employee {
  id: number;
  name: string;
  phone: string;
  email: string;
  joining: string;
  role: string;
  dept: string;
  salary: number;
  month: string;
  status: 'paid' | 'pending';
  username?: string;
  password?: string;
}

// Add this interface at the top (after Employee interface)
export interface SalaryRecord {
  id: number;
  employeeId: number;
  employeeName: string;
  role: string;
  dept: string;
  salary: number;
  month: string;
  paidOn: string;       // date paid
  paymentMode: string;  // Cash / Bank Transfer / UPI
  // notes: string;
}

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  // ── Data ──
  employees: Employee[] = [
    { id:1, name:'Rajesh Kumar', phone:'+91 98765 43210', email:'rajesh@rest.com', joining:'2023-01-15', role:'Head Chef',        dept:'Kitchen',        salary:25000, month:'2026-02', status:'paid' },
    { id:2, name:'Priya Sharma', phone:'+91 87654 32109', email:'priya@rest.com',  joining:'2023-03-10', role:'Sous Chef',         dept:'Kitchen',        salary:18000, month:'2026-02', status:'paid' },
    { id:3, name:'Amit Patel',   phone:'+91 76543 21098', email:'amit@rest.com',   joining:'2024-06-01', role:'Waiter',            dept:'Front of House', salary:12000, month:'2026-02', status:'pending', username:'amit.patel',  password:'Waiter@123' },
    { id:4, name:'Sunita Devi',  phone:'+91 65432 10987', email:'sunita@rest.com', joining:'2024-02-20', role:'Cashier',           dept:'Front of House', salary:14000, month:'2026-02', status:'pending' },
    { id:5, name:'Vikram Singh', phone:'+91 54321 09876', email:'vikram@rest.com', joining:'2023-08-05', role:'Delivery Boy',      dept:'Delivery',       salary:10000, month:'2026-02', status:'paid' },
    { id:6, name:'Meena Rao',    phone:'+91 43210 98765', email:'meena@rest.com',  joining:'2022-11-12', role:'Manager',           dept:'Management',     salary:35000, month:'2026-02', status:'paid',    username:'meena.rao',   password:'Manager@456' },
    { id:7, name:'Suresh Nair',  phone:'+91 32109 87654', email:'suresh@rest.com', joining:'2025-01-08', role:'Chef',              dept:'Kitchen',        salary:16000, month:'2026-01', status:'paid' },
    { id:8, name:'Kavya Thomas', phone:'+91 21098 76543', email:'kavya@rest.com',  joining:'2025-04-01', role:'Kitchen Assistant', dept:'Kitchen',        salary:9000,  month:'2026-01', status:'pending' },
  ];
  private nextId = 9;

  // ── Constants ──
  readonly ROLES = [
    'Head Chef', 'Sous Chef', 'Chef', 'Kitchen Assistant',
    'Waiter', 'Cashier', 'Delivery Boy', 'Manager'
  ];
  readonly DEPTS = ['Kitchen', 'Front of House', 'Delivery', 'Management'];

  // Roles that require login credentials
  readonly CREDENTIAL_ROLES = ['Manager', 'Waiter'];

  readonly DEPT_CLASS: any = {
    'Kitchen':       'dept-kitchen',
    'Front of House':'dept-front',
    'Delivery':      'dept-delivery',
    'Management':    'dept-management',
  };

  // ── Filter state ──
  searchText: string   = '';
  statusFilter: string = 'all';
  deptFilter: string   = 'all';
  roleFilter: string   = 'all';
  monthFilter: string  = 'all';

  // ── Available months for filter ──
  months: { value: string; label: string }[] = [
    { value:'2026-02', label:'Feb 2026' },
    { value:'2026-01', label:'Jan 2026' },
    { value:'2025-12', label:'Dec 2025' },
  ];

  // ── Filtered + paginated ──
  filtered: Employee[] = [];
  page: number         = 1;
  readonly PAGE_SIZE   = 6;

  // ── Modal ──
  showModal: boolean    = false;
  isEditing: boolean    = false;
  editingId: number | null = null;

  // Form fields
  fName: string     = '';
  fPhone: string    = '';
  fEmail: string    = '';
  fJoining: string  = '';
  fRole: string     = '';
  fDept: string     = '';
  fSalary: number | null = null;
  fMonth: string    = '';
  fStatus: string   = 'pending';
  fUsername: string = '';
  fPassword: string = '';

  // Password visibility
  showPassword: boolean = false;

  // Form errors
  errName: boolean     = false;
  errPhone: boolean    = false;
  errEmail: boolean    = false;
  errJoining: boolean  = false;
  errRole: boolean     = false;
  errDept: boolean     = false;
  errSalary: boolean   = false;
  errMonth: boolean    = false;
  errUsername: boolean = false;
  errPassword: boolean = false;

  // ── Confirm delete ──
  showConfirm: boolean  = false;
  confirmMsg: string    = '';
  pendingDeleteId: number | null = null;

  // ── Toast ──
  toastMsg: string      = '';
  toastType: string     = '';
  toastVisible: boolean = false;
  private toastTimer: any;

  // ── Salary Modal ──
  showSalaryModal: boolean     = false;
  salaryEmpId: number | null   = null;
  salaryEmpName: string        = '';
  salaryEmpRole: string        = '';
  salaryEmpDept: string        = '';
  salaryAmount: number | null  = null;
  salaryMonth: string          = '';
  salaryPaidOn: string         = '';
  salaryPayMode: string        = 'Cash';

  // Salary form errors
  errSalaryMonth:   boolean = false;
  errSalaryPaidOn:  boolean = false;
  errSalaryAmount:  boolean = false;
  errSalaryPayMode: boolean = false;

  // Salary history
  salaryRecords: SalaryRecord[] = [];
  private salaryNextId: number  = 1;

  // Show history panel inside salary modal
  showSalaryHistory: boolean = false;

  readonly PAY_MODES = ['Cash', 'Bank Transfer', 'UPI', 'Cheque'];

  ngOnInit(): void {
    this.applyFilters();
  }

  // ── Computed: does selected role need credentials? ──
  get needsCredentials(): boolean {
    return this.CREDENTIAL_ROLES.includes(this.fRole);
  }

  // ── Filters ──
  applyFilters(): void {
    const s = this.searchText.toLowerCase().trim();
    this.filtered = this.employees.filter(e => {
      if (s && !e.name.toLowerCase().includes(s) && !e.role.toLowerCase().includes(s)) return false;
      if (this.statusFilter !== 'all' && e.status !== this.statusFilter) return false;
      if (this.deptFilter   !== 'all' && e.dept   !== this.deptFilter)   return false;
      if (this.roleFilter   !== 'all' && e.role   !== this.roleFilter)   return false;
      if (this.monthFilter  !== 'all' && e.month  !== this.monthFilter)  return false;
      return true;
    });
    this.page = 1;
  }

  // ── Pagination ──
  get pagedItems(): Employee[] {
    const start = (this.page - 1) * this.PAGE_SIZE;
    return this.filtered.slice(start, start + this.PAGE_SIZE);
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.filtered.length / this.PAGE_SIZE));
  }

  prevPage(): void { if (this.page > 1) this.page--; }
  nextPage(): void { if (this.page < this.totalPages) this.page++; }

  // ── Mark as paid ──
  markPaid(id: number): void {
    const emp = this.employees.find(e => e.id === id);
    if (!emp) return;
    emp.status = 'paid';
    this.applyFilters();
    this.showToast(`"${emp.name}" marked as paid!`, 'success');
  }

  // ── Modal open/close ──
  openAddModal(): void {
    this.isEditing  = false;
    this.editingId  = null;
    this.clearForm();
    // Default joining to today, month to current month
    const now = new Date();
    this.fJoining = now.toISOString().split('T')[0];
    this.fMonth   = now.toISOString().slice(0, 7);
    this.showModal = true;
  }

  openEditModal(id: number): void {
    const emp = this.employees.find(e => e.id === id);
    if (!emp) return;
    this.isEditing  = true;
    this.editingId  = id;
    this.fName      = emp.name;
    this.fPhone     = emp.phone;
    this.fEmail     = emp.email;
    this.fJoining   = emp.joining;
    this.fRole      = emp.role;
    this.fDept      = emp.dept;
    this.fSalary    = emp.salary;
    this.fMonth     = emp.month;
    this.fStatus    = emp.status;
    this.fUsername  = emp.username || '';
    this.fPassword  = emp.password || '';
    this.showPassword = false;
    this.clearErrors();
    this.showModal  = true;
  }

  closeModal(): void {
    this.showModal = false;
    this.clearForm();
  }

  clearForm(): void {
    this.fName = ''; this.fPhone = ''; this.fEmail = '';
    this.fJoining = ''; this.fRole = ''; this.fDept = '';
    this.fSalary = null; this.fMonth = ''; this.fStatus = 'pending';
    this.fUsername = ''; this.fPassword = '';
    this.showPassword = false;
    this.clearErrors();
  }

  clearErrors(): void {
    this.errName = false; this.errPhone = false; this.errEmail = false;
    this.errJoining = false; this.errRole = false; this.errDept = false;
    this.errSalary = false; this.errMonth = false;
    this.errUsername = false; this.errPassword = false;
  }

  // ── On role change — clear credentials if role no longer needs them ──
  onRoleChange(): void {
    if (!this.needsCredentials) {
      this.fUsername = '';
      this.fPassword = '';
      this.errUsername = false;
      this.errPassword = false;
    }
  }

  // ── Toggle password visibility ──
  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }

  // ── Save ──
  saveEmployee(): void {
    this.clearErrors();
    let ok = true;

    if (!this.fName.trim())                              { this.errName    = true; ok = false; }
    if (!this.fPhone.trim())                             { this.errPhone   = true; ok = false; }
    if (!this.fEmail.trim())                             { this.errEmail   = true; ok = false; }
    if (!this.fJoining)                                  { this.errJoining = true; ok = false; }
    if (!this.fRole)                                     { this.errRole    = true; ok = false; }
    if (!this.fDept)                                     { this.errDept    = true; ok = false; }
    if (this.fSalary === null || this.fSalary < 0)       { this.errSalary  = true; ok = false; }
    if (!this.fMonth)                                    { this.errMonth   = true; ok = false; }
    if (this.needsCredentials && !this.fUsername.trim()) { this.errUsername = true; ok = false; }
    if (this.needsCredentials && !this.fPassword.trim()) { this.errPassword = true; ok = false; }

    if (!ok) return;

    const empData: any = {
      name:    this.fName.trim(),
      phone:   this.fPhone.trim(),
      email:   this.fEmail.trim(),
      joining: this.fJoining,
      role:    this.fRole,
      dept:    this.fDept,
      salary:  this.fSalary!,
      month:   this.fMonth,
      status:  this.fStatus as 'paid' | 'pending',
    };

    // Only include credentials for relevant roles
    if (this.needsCredentials) {
      empData.username = this.fUsername.trim();
      empData.password = this.fPassword.trim();
    }

    if (this.isEditing && this.editingId !== null) {
      const idx = this.employees.findIndex(e => e.id === this.editingId);
      if (idx > -1) this.employees[idx] = { ...this.employees[idx], ...empData };
      this.showToast(`"${empData.name}" updated!`, 'success');
    } else {
      this.employees.push({ id: this.nextId++, ...empData });
      this.ensureMonthInFilter(empData.month);
      this.showToast(`"${empData.name}" added successfully!`, 'success');
    }

    this.closeModal();
    this.applyFilters();
  }

  // ── Delete ──
  confirmDelete(id: number): void {
    const emp = this.employees.find(e => e.id === id);
    if (!emp) return;
    this.pendingDeleteId = id;
    this.confirmMsg      = `Delete "${emp.name}"? This cannot be undone.`;
    this.showConfirm     = true;
  }

  cancelDelete(): void {
    this.showConfirm     = false;
    this.pendingDeleteId = null;
  }

  doDelete(): void {
    if (this.pendingDeleteId !== null) {
      const emp      = this.employees.find(e => e.id === this.pendingDeleteId);
      this.employees = this.employees.filter(e => e.id !== this.pendingDeleteId);
      this.pendingDeleteId = null;
      this.showConfirm = false;
      this.closeModal();
      this.applyFilters();
      this.showToast(`"${emp?.name}" deleted.`, 'danger');
    }
  }

  // ── Helpers ──
  ensureMonthInFilter(month: string): void {
    if (this.months.some(m => m.value === month)) return;
    const [y, m] = month.split('-');
    const label  = new Date(+y, +m - 1).toLocaleString('en-IN', { month:'short', year:'numeric' });
    this.months.push({ value: month, label });
  }

  formatMonth(m: string): string {
    const [y, mo] = m.split('-');
    return new Date(+y, +mo - 1).toLocaleString('en-IN', { month:'short', year:'numeric' });
  }

  // ════════════════════════════════════════
  // SALARY MODAL
  // ════════════════════════════════════════

  openSalaryModal(id: number): void {
    const emp = this.employees.find(e => e.id === id);
    if (!emp) return;

    this.salaryEmpId    = emp.id;
    this.salaryEmpName  = emp.name;
    this.salaryEmpRole  = emp.role;
    this.salaryEmpDept  = emp.dept;
    this.salaryAmount   = emp.salary;
    this.salaryMonth    = emp.month;
    this.salaryPaidOn   = new Date().toISOString().split('T')[0];
    this.salaryPayMode  = 'Cash';
    this.showSalaryHistory = false;
    this.clearSalaryErrors();
    this.showSalaryModal   = true;
  }

  closeSalaryModal(): void {
    this.showSalaryModal   = false;
    this.salaryEmpId       = null;
    this.showSalaryHistory = false;
    this.clearSalaryErrors();
  }

  clearSalaryErrors(): void {
    this.errSalaryMonth   = false;
    this.errSalaryPaidOn  = false;
    this.errSalaryAmount  = false;
    this.errSalaryPayMode = false;
  }

  saveSalary(): void {
    this.clearSalaryErrors();
    let ok = true;

    if (!this.salaryMonth)                              { this.errSalaryMonth   = true; ok = false; }
    if (!this.salaryPaidOn)                             { this.errSalaryPaidOn  = true; ok = false; }
    if (this.salaryAmount === null || this.salaryAmount <= 0) { this.errSalaryAmount = true; ok = false; }
    if (!this.salaryPayMode)                            { this.errSalaryPayMode = true; ok = false; }

    if (!ok) return;

    // Check duplicate payment for same month
    const alreadyPaid = this.salaryRecords.some(
      r => r.employeeId === this.salaryEmpId && r.month === this.salaryMonth
    );
    if (alreadyPaid) {
      this.showToast(`Salary already paid for ${this.formatMonth(this.salaryMonth)}!`, 'danger');
      return;
    }

    const record: SalaryRecord = {
      id:           this.salaryNextId++,
      employeeId:   this.salaryEmpId!,
      employeeName: this.salaryEmpName,
      role:         this.salaryEmpRole,
      dept:         this.salaryEmpDept,
      salary:       this.salaryAmount!,
      month:        this.salaryMonth,
      paidOn:       this.salaryPaidOn,
      paymentMode:  this.salaryPayMode,
    };

    this.salaryRecords.push(record);

    // Mark employee status as paid for that month
    const emp = this.employees.find(e => e.id === this.salaryEmpId);
    if (emp && emp.month === this.salaryMonth) {
      emp.status = 'paid';
      this.applyFilters();
    }

    this.showToast(
      `₹${this.salaryAmount!.toLocaleString('en-IN')} salary paid to "${this.salaryEmpName}"!`,
      'success'
    );
    this.closeSalaryModal();
  }

  // Returns salary records for the currently selected employee
  get currentEmpSalaryHistory(): SalaryRecord[] {
    return this.salaryRecords
      .filter(r => r.employeeId === this.salaryEmpId)
      .sort((a, b) => b.month.localeCompare(a.month));
  }

  // Total paid to this employee across all months
  get currentEmpTotalPaid(): number {
    return this.currentEmpSalaryHistory.reduce((s, r) => s + r.salary, 0);
  }

  fmtDate(iso: string): string {
    return new Date(iso + 'T00:00:00').toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric'
    });
  }




  // ── Toast ──
  showToast(msg: string, type: string = 'info'): void {
    this.toastMsg     = msg;
    this.toastType    = type;
    this.toastVisible = true;
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => this.toastVisible = false, 2800);
  }
}