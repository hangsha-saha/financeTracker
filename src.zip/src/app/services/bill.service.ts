import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface MenuItemOption {
  name:     string;
  price:    number;
  category: string;
}

export interface VoucherData {
  code:  string;
  type:  'percent' | 'flat';
  value: number;
  label: string;
}

@Injectable({ providedIn: 'root' })
export class BillService {

  private readonly MENU_URL    = 'assets/data/menu.json';
  private readonly VOUCHER_URL = 'assets/data/vouchers.json';

  constructor(private http: HttpClient) {}

  getMenuItems(): Observable<MenuItemOption[]> {
    return this.http.get<MenuItemOption[]>(this.MENU_URL);
  }

  getVouchers(): Observable<VoucherData[]> {
    return this.http.get<VoucherData[]>(this.VOUCHER_URL);
  }
}