import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

// ── Matches exact API response structure ──
export interface InventoryUser {
  userId:    number;
  userName:  string;
  email:     string;
  password:  string;
  role:      string;
  createdAt: string | null;
}

export interface InventoryVendor {
  vendorId:      string;
  name:          string;
  phoneNumber:   number;
  email:         string;
  amountPending: number;
  address:       string | null;
  note:          string;
  createdAt:     string;
  dueDate:       string;
  user:          InventoryUser;
}

export interface InventoryApiItem {
  inventoryId:     string;
  itemName:        string;
  category:        string;
  unit:            string;
  unitCost:        number;
  quantity:        number;
  usedQuantity:    number;
  minimumQuantity: number;
  note:            string;
  currentDate:     string;
  vendorId:        InventoryVendor;   // nested vendor object
  user:            InventoryUser;     // nested user object
}

// ── Payload for POST /inventory/add ──
export interface InventoryAddPayload {
  itemName:        string;
  category:        string;
  unit:            string;
  unitCost:        number;
  quantity:        number;
  usedQuantity:    number;
  minimumQuantity: number;
  note:            string;
}

// ── Payload for PUT /inventory/update/:id ──
export interface InventoryUpdatePayload {
  itemName:        string;
  category:        string;
  unit:            string;
  unitCost:        number;
  quantity:        number;
  usedQuantity:    number;
  minimumQuantity: number;
  note:            string;
}

@Injectable({ providedIn: 'root' })
export class InventoryService {

  private readonly BASE = 'http://192.168.1.39:3000/inventory';

  constructor(private http: HttpClient) {}

  // GET all → filter by userId in component
  getAll(): Observable<InventoryApiItem[]> {
    return this.http.get<InventoryApiItem[]>(`${this.BASE}/all`);
  }

  // GET by inventoryId
  getById(inventoryId: string): Observable<InventoryApiItem> {
    return this.http.get<InventoryApiItem>(`${this.BASE}/get/${inventoryId}`);
  }

  // GET by vendorId
  getByVendor(vendorId: string): Observable<InventoryApiItem[]> {
    return this.http.get<InventoryApiItem[]>(`${this.BASE}/vendor/${vendorId}`);
  }

  // POST add — vendorId passed as query param
  add(payload: InventoryAddPayload, vendorId: string): Observable<InventoryApiItem> {
    return this.http.post<InventoryApiItem>(
      `${this.BASE}/add?vendorId=${vendorId}`,
      payload
    );
  }

  // PUT update
  update(inventoryId: string, payload: InventoryUpdatePayload): Observable<InventoryApiItem> {
    return this.http.put<InventoryApiItem>(
      `${this.BASE}/update/${inventoryId}`,
      payload
    );
  }

  // DELETE
  delete(inventoryId: string): Observable<any> {
    return this.http.delete(`${this.BASE}/delete/${inventoryId}`);
  }

  // ── Helper: filter by userId after fetching all ──
  getByUserId(userId: number): Observable<InventoryApiItem[]> {
    return this.getAll().pipe(
      map(items => items.filter(item => item.user.userId === userId))
    );
  }
}