import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  // ── Form fields ──
  username: string  = '';
  email: string     = '';
  password: string  = '';
  agreement: boolean = false;

  // ── UI state ──
  isLoading: boolean    = false;
  showPassword: boolean = false;

  // ── Validation errors ──
  errUsername: string = '';
  errEmail: string    = '';
  errPassword: string = '';
  errAgreement: string = '';

  // ── Username duplicate check (replace with API call) ──
  private readonly TAKEN_USERNAMES = ['admin', 'manager1', 'johndoe'];

  // ── Password strength ──
  strengthWidth: string = '0%';
  strengthColor: string = '';
  strengthLabel: string = '';
  showStrength: boolean = false;

  constructor(private router: Router) {}

  // ── Toggle password visibility ──
  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }

  // ── Password strength check ──
  onPasswordInput(): void {
    const v = this.password;

    if (!v) {
      this.showStrength = false;
      return;
    }

    this.showStrength = true;
    let strength = 0;

    if (v.length >= 8)              strength++;
    if (v.length >= 12)             strength++;
    if (/[a-z]/.test(v))            strength++;
    if (/[A-Z]/.test(v))            strength++;
    if (/\d/.test(v))               strength++;
    if (/[!@#$%^&*]/.test(v))       strength++;

    if (strength <= 2) {
      this.strengthWidth = '33%';
      this.strengthColor = 'var(--danger)';
      this.strengthLabel = 'Password strength: Weak';
    } else if (strength <= 4) {
      this.strengthWidth = '66%';
      this.strengthColor = 'var(--warning)';
      this.strengthLabel = 'Password strength: Fair';
    } else {
      this.strengthWidth = '100%';
      this.strengthColor = 'var(--success)';
      this.strengthLabel = 'Password strength: Strong';
    }

    // Clear error while typing
    if (this.errPassword) this.errPassword = '';
  }

  // ── Real-time username check on blur ──
  onUsernameBlur(): void {
    if (!this.username.trim()) return;
    if (this.TAKEN_USERNAMES.includes(this.username.toLowerCase())) {
      this.errUsername = 'Username already taken. Choose another.';
    } else {
      this.errUsername = '';
    }
  }

  // ── Real-time email check on blur ──
  onEmailBlur(): void {
    if (!this.email.trim()) return;
    if (!this.validEmail(this.email)) {
      this.errEmail = 'Please enter a valid email address.';
    } else {
      this.errEmail = '';
    }
  }

  // ── Validate all fields ──
  validate(): boolean {
    this.errUsername = '';
    this.errEmail    = '';
    this.errPassword = '';
    this.errAgreement = '';
    let ok = true;

    if (!this.username.trim()) {
      this.errUsername = 'Username is required.'; ok = false;
    } else if (this.username.length < 3) {
      this.errUsername = 'Username must be at least 3 characters.'; ok = false;
    } else if (!/^[a-zA-Z0-9_]+$/.test(this.username)) {
      this.errUsername = 'Only letters, numbers, and underscores allowed.'; ok = false;
    } else if (this.TAKEN_USERNAMES.includes(this.username.toLowerCase())) {
      this.errUsername = 'Username already taken. Choose another.'; ok = false;
    }

    if (!this.email.trim()) {
      this.errEmail = 'Email is required.'; ok = false;
    } else if (!this.validEmail(this.email)) {
      this.errEmail = 'Please enter a valid email address.'; ok = false;
    }

    if (!this.password) {
      this.errPassword = 'Password is required.'; ok = false;
    } else if (this.password.length < 8) {
      this.errPassword = 'Password must be at least 8 characters.'; ok = false;
    }

    if (!this.agreement) {
      this.errAgreement = 'You must accept the Terms of Service and Privacy Policy.'; ok = false;
    }

    return ok;
  }

  // ── Submit ──
  handleRegister(): void {
    if (!this.validate()) return;

    this.isLoading = true;

    // ── DUMMY SIMULATION (replace with real API call) ──
    // Example API call:
    // this.http.post<ApiResponse>(`${this.API_BASE}/auth/register`, {
    //   username: this.username,
    //   email: this.email,
    //   password: this.password
    // }).pipe(
    //   catchError(err => { this.isLoading = false; ... }),
    //   finalize(() => this.isLoading = false)
    // ).subscribe(res => {
    //   this.router.navigate(['/login']);
    // });

    setTimeout(() => {
      this.isLoading = false;
      // On success navigate to login
      this.router.navigate(['/login']);
    }, 2000);
  }

  // ── Helper ──
  private validEmail(email: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }
}