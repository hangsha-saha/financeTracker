import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { InventoryComponent } from './inventory/inventory.component';
import { IncomeComponent } from './income/income.component';
import { ExpenseComponent } from './expense/expense.component';
import { MenuComponent } from './menu/menu.component';
import { GenerateBillComponent } from './generate-bill/generate-bill.component';
import { EmployeesComponent } from './employees/employees.component';
import { ProfileComponent } from './profile/profile.component';
import { VendorsComponent } from './vendors/vendors.component';
import { RegisterComponent } from './register/register.component';
import { LandingComponent } from './landing/landing.component';
import { ViewBillsComponent } from './view-bills/view-bills.component';
import { ReportsComponent } from './reports/reports.component';

const routes: Routes = [
  // { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: '', component: LandingComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'inventory', component: InventoryComponent },
  { path: 'income', component: IncomeComponent },
  { path: 'expense', component: ExpenseComponent },
  { path: 'menu', component: MenuComponent },
  { path: 'generate-bill', component: GenerateBillComponent },
  {path: 'employees', component: EmployeesComponent},
  {path: 'profile', component: ProfileComponent},
  {path: 'vendors', component: VendorsComponent},
  {path: 'view-bills', component: ViewBillsComponent},
  {path: 'reports', component: ReportsComponent},

  // ── Wildcard: catch all unbuilt routes ──
  { path: '**', redirectTo: '' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }